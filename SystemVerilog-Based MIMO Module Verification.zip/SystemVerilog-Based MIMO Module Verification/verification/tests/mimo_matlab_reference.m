%% MIMO Encoder Reference Model
% Description: MATLAB reference model for MIMO encoder verification
% Author: SystemVerilog MIMO Verification Team
% Date: August 2025

classdef MIMOEncoder < handle
    properties
        numTxAntennas
        numDataStreams
        mimoMode
        modulationType
        symbolWidth
        dataWidth
    end
    
    methods
        function obj = MIMOEncoder(numTx, numStreams, symWidth, dataWidth)
            % Constructor
            obj.numTxAntennas = numTx;
            obj.numDataStreams = numStreams;
            obj.symbolWidth = symWidth;
            obj.dataWidth = dataWidth;
        end
        
        function symbols = encode(obj, dataStreams, mimoMode, modType)
            % Main encoding function
            obj.mimoMode = mimoMode;
            obj.modulationType = modType;
            
            % Step 1: Modulate data streams
            modulatedSymbols = obj.modulate(dataStreams);
            
            % Step 2: Apply spatial precoding/multiplexing
            symbols = obj.spatialPrecoding(modulatedSymbols);
        end
        
        function modulatedSymbols = modulate(obj, dataStreams)
            % Modulation based on modulation type
            numStreams = length(dataStreams);
            modulatedSymbols = zeros(numStreams, 1);
            
            for i = 1:numStreams
                switch obj.modulationType
                    case 0 % BPSK
                        modulatedSymbols(i) = obj.bpskModulate(dataStreams(i));
                    case 1 % QPSK
                        modulatedSymbols(i) = obj.qpskModulate(dataStreams(i));
                    case 2 % 16-QAM
                        modulatedSymbols(i) = obj.qam16Modulate(dataStreams(i));
                    case 3 % 64-QAM
                        modulatedSymbols(i) = obj.qam64Modulate(dataStreams(i));
                    otherwise
                        error('Invalid modulation type');
                end
            end
        end
        
        function symbol = bpskModulate(obj, dataByte)
            % BPSK modulation
            bit = bitget(dataByte, 1);
            if bit == 1
                symbol = 1 + 1j*0;
            else
                symbol = -1 + 1j*0;
            end
        end
        
        function symbol = qpskModulate(obj, dataByte)
            % QPSK modulation
            bits = [bitget(dataByte, 2), bitget(dataByte, 1)];
            constellation = [1+1j, -1+1j, 1-1j, -1-1j] / sqrt(2);
            symbolIndex = bi2de(bits) + 1;
            symbol = constellation(symbolIndex);
        end
        
        function symbol = qam16Modulate(obj, dataByte)
            % 16-QAM modulation
            bits = zeros(1, 4);
            for i = 1:4
                bits(i) = bitget(dataByte, i);
            end
            
            % 16-QAM constellation
            constellation = zeros(1, 16);
            for i = 0:15
                iBits = de2bi(i, 4);
                iSym = (2*iBits(4) - 1) + 1j*(2*iBits(3) - 1);
                qSym = (2*iBits(2) - 1) + 1j*(2*iBits(1) - 1);
                constellation(i+1) = (iSym + qSym) / sqrt(10);
            end
            
            symbolIndex = bi2de(bits) + 1;
            symbol = constellation(symbolIndex);
        end
        
        function symbol = qam64Modulate(obj, dataByte)
            % 64-QAM modulation (simplified - uses only 6 bits)
            bits = zeros(1, 6);
            for i = 1:6
                bits(i) = bitget(dataByte, i);
            end
            
            % 64-QAM constellation (simplified)
            symbolIndex = bi2de(bits) + 1;
            
            % Create constellation points
            constellation = zeros(1, 64);
            for i = 0:63
                iBits = de2bi(i, 6);
                real_part = (2*bi2de(iBits(6:-1:4)) - 7) / sqrt(42);
                imag_part = (2*bi2de(iBits(3:-1:1)) - 7) / sqrt(42);
                constellation(i+1) = real_part + 1j*imag_part;
            end
            
            symbol = constellation(symbolIndex);
        end
        
        function precodedSymbols = spatialPrecoding(obj, modulatedSymbols)
            % Spatial precoding based on MIMO mode
            precodedSymbols = zeros(obj.numTxAntennas, 1);
            
            switch obj.mimoMode
                case 0 % SISO
                    precodedSymbols(1) = modulatedSymbols(1);
                    
                case 1 % SIMO (transmit from one antenna)
                    precodedSymbols(1) = modulatedSymbols(1);
                    
                case 2 % MISO (transmit diversity)
                    % Simple diversity - duplicate signal
                    for i = 1:obj.numTxAntennas
                        precodedSymbols(i) = modulatedSymbols(1);
                    end
                    
                case 3 % MIMO (spatial multiplexing)
                    numStreams = min(length(modulatedSymbols), obj.numTxAntennas);
                    for i = 1:numStreams
                        precodedSymbols(i) = modulatedSymbols(i);
                    end
                    
                otherwise
                    error('Invalid MIMO mode');
            end
        end
        
        function result = validateEncoding(obj, inputData, outputSymbols, expectedSymbols)
            % Validation function for testbench integration
            tolerance = 1e-6;
            
            if length(outputSymbols) ~= length(expectedSymbols)
                result = false;
                return;
            end
            
            maxError = max(abs(outputSymbols - expectedSymbols));
            result = maxError < tolerance;
        end
        
    end
end

%% MIMO Decoder Reference Model

classdef MIMODecoder < handle
    properties
        numRxAntennas
        numDataStreams
        mimoMode
        modulationType
        detectionAlgorithm
        channelMatrix
        noiseVariance
    end
    
    methods
        function obj = MIMODecoder(numRx, numStreams)
            obj.numRxAntennas = numRx;
            obj.numDataStreams = numStreams;
            obj.noiseVariance = 0.1; % Default noise variance
        end
        
        function decodedData = decode(obj, rxSymbols, channelMatrix, mimoMode, modType, detAlgo)
            % Main decoding function
            obj.channelMatrix = channelMatrix;
            obj.mimoMode = mimoMode;
            obj.modulationType = modType;
            obj.detectionAlgorithm = detAlgo;
            
            % Step 1: MIMO detection
            detectedSymbols = obj.mimoDetection(rxSymbols);
            
            % Step 2: Demodulation
            decodedData = obj.demodulate(detectedSymbols);
        end
        
        function detectedSymbols = mimoDetection(obj, rxSymbols)
            % MIMO detection based on algorithm
            switch obj.detectionAlgorithm
                case 0 % Zero Forcing
                    detectedSymbols = obj.zeroForcing(rxSymbols);
                case 1 % MMSE
                    detectedSymbols = obj.mmseDetection(rxSymbols);
                case 2 % Maximum Likelihood
                    detectedSymbols = obj.mlDetection(rxSymbols);
                case 3 % Successive Interference Cancellation
                    detectedSymbols = obj.sicDetection(rxSymbols);
                otherwise
                    error('Invalid detection algorithm');
            end
        end
        
        function symbols = zeroForcing(obj, rxSymbols)
            % Zero Forcing detection
            H = obj.channelMatrix;
            
            if rank(H) < size(H, 2)
                % Channel matrix is not full rank
                symbols = zeros(obj.numDataStreams, 1);
                return;
            end
            
            % Pseudo-inverse for rectangular matrices
            if size(H, 1) >= size(H, 2)
                W = pinv(H); % (H^H * H)^-1 * H^H
            else
                W = H' * pinv(H * H'); % H^H * (H * H^H)^-1
            end
            
            symbols = W * rxSymbols;
        end
        
        function symbols = mmseDetection(obj, rxSymbols)
            % MMSE detection
            H = obj.channelMatrix;
            I = eye(size(H, 2));
            
            % MMSE filter: W = (H^H * H + σ²I)^-1 * H^H
            W = inv(H' * H + obj.noiseVariance * I) * H';
            symbols = W * rxSymbols;
        end
        
        function symbols = mlDetection(obj, rxSymbols)
            % Maximum Likelihood detection (simplified)
            % This is computationally intensive, so we use a simplified approach
            H = obj.channelMatrix;
            
            % For simplicity, use MMSE as approximation to ML
            symbols = obj.mmseDetection(rxSymbols);
            
            % In practice, ML would search over all possible transmitted symbols
            % and choose the one that minimizes ||y - Hx||²
        end
        
        function symbols = sicDetection(obj, rxSymbols)
            % Successive Interference Cancellation
            H = obj.channelMatrix;
            y = rxSymbols;
            symbols = zeros(obj.numDataStreams, 1);
            
            % QR decomposition for ordered SIC
            [Q, R] = qr(H);
            y_transformed = Q' * y;
            
            % Back substitution
            for i = obj.numDataStreams:-1:1
                % Detect symbol for stream i
                symbols(i) = y_transformed(i) / R(i, i);
                
                % Hard decision
                symbols(i) = obj.hardDecision(symbols(i));
                
                % Subtract interference for previous streams
                for j = 1:i-1
                    y_transformed(j) = y_transformed(j) - R(j, i) * symbols(i);
                end
            end
        end
        
        function hardSym = hardDecision(obj, softSym)
            % Hard decision based on modulation type
            switch obj.modulationType
                case 0 % BPSK
                    hardSym = sign(real(softSym));
                case 1 % QPSK
                    hardSym = sign(real(softSym)) + 1j*sign(imag(softSym));
                    hardSym = hardSym / sqrt(2);
                case {2, 3} % 16-QAM, 64-QAM
                    % Simplified hard decision
                    hardSym = sign(real(softSym)) + 1j*sign(imag(softSym));
                otherwise
                    hardSym = softSym;
            end
        end
        
        function decodedData = demodulate(obj, detectedSymbols)
            % Demodulation to recover data bits
            numSymbols = length(detectedSymbols);
            decodedData = zeros(numSymbols, 1);
            
            for i = 1:numSymbols
                switch obj.modulationType
                    case 0 % BPSK
                        decodedData(i) = obj.bpskDemodulate(detectedSymbols(i));
                    case 1 % QPSK
                        decodedData(i) = obj.qpskDemodulate(detectedSymbols(i));
                    case 2 % 16-QAM
                        decodedData(i) = obj.qam16Demodulate(detectedSymbols(i));
                    case 3 % 64-QAM
                        decodedData(i) = obj.qam64Demodulate(detectedSymbols(i));
                end
            end
        end
        
        function dataByte = bpskDemodulate(obj, symbol)
            % BPSK demodulation
            if real(symbol) >= 0
                dataByte = 1;
            else
                dataByte = 0;
            end
        end
        
        function dataByte = qpskDemodulate(obj, symbol)
            % QPSK demodulation
            realBit = real(symbol) >= 0;
            imagBit = imag(symbol) >= 0;
            dataByte = 2*realBit + imagBit;
        end
        
        function dataByte = qam16Demodulate(obj, symbol)
            % 16-QAM demodulation (simplified)
            realPart = real(symbol);
            imagPart = imag(symbol);
            
            % Quantize to nearest constellation point
            realBits = [realPart >= 0, abs(realPart) >= 2/sqrt(10)];
            imagBits = [imagPart >= 0, abs(imagPart) >= 2/sqrt(10)];
            
            bits = [realBits, imagBits];
            dataByte = bi2de(bits);
        end
        
        function dataByte = qam64Demodulate(obj, symbol)
            % 64-QAM demodulation (simplified)
            dataByte = mod(abs(floor(real(symbol)*8) + floor(imag(symbol)*8)*8), 64);
        end
        
        function ber = calculateBER(obj, originalData, decodedData)
            % Calculate Bit Error Rate
            if length(originalData) ~= length(decodedData)
                error('Data length mismatch');
            end
            
            totalBits = 0;
            errorBits = 0;
            
            for i = 1:length(originalData)
                switch obj.modulationType
                    case 0 % BPSK - 1 bit per symbol
                        bitsPerSymbol = 1;
                    case 1 % QPSK - 2 bits per symbol
                        bitsPerSymbol = 2;
                    case 2 % 16-QAM - 4 bits per symbol
                        bitsPerSymbol = 4;
                    case 3 % 64-QAM - 6 bits per symbol
                        bitsPerSymbol = 6;
                end
                
                origBits = de2bi(originalData(i), bitsPerSymbol);
                decoBits = de2bi(decodedData(i), bitsPerSymbol);
                
                errorBits = errorBits + sum(origBits ~= decoBits);
                totalBits = totalBits + bitsPerSymbol;
            end
            
            ber = errorBits / totalBits;
        end
        
    end
end

%% Channel Estimation Reference Model

classdef MIMOChannelEstimator < handle
    properties
        numTxAntennas
        numRxAntennas
        estimationAlgorithm
        pilotPattern
        timeVaryingChannel
    end
    
    methods
        function obj = MIMOChannelEstimator(numTx, numRx)
            obj.numTxAntennas = numTx;
            obj.numRxAntennas = numRx;
        end
        
        function channelMatrix = estimate(obj, txPilots, rxPilots, algorithm, pilotPattern, timeVarying)
            obj.estimationAlgorithm = algorithm;
            obj.pilotPattern = pilotPattern;
            obj.timeVaryingChannel = timeVarying;
            
            switch algorithm
                case 0 % Least Squares
                    channelMatrix = obj.leastSquares(txPilots, rxPilots);
                case 1 % MMSE
                    channelMatrix = obj.mmseEstimation(txPilots, rxPilots);
                case 2 % Maximum Likelihood
                    channelMatrix = obj.mlEstimation(txPilots, rxPilots);
                case 3 % Adaptive
                    channelMatrix = obj.adaptiveEstimation(txPilots, rxPilots);
                otherwise
                    error('Invalid estimation algorithm');
            end
            
            if timeVarying
                channelMatrix = obj.temporalFiltering(channelMatrix);
            end
        end
        
        function H = leastSquares(obj, X, Y)
            % Least Squares channel estimation
            % Y = HX + N, where H is the channel matrix
            % LS estimate: H_est = Y * X^H * (X * X^H)^-1
            
            if size(X, 2) < obj.numTxAntennas
                % Pad pilots if needed
                X_padded = [X, zeros(size(X, 1), obj.numTxAntennas - size(X, 2))];
            else
                X_padded = X(:, 1:obj.numTxAntennas);
            end
            
            if size(Y, 2) < obj.numRxAntennas
                % Pad received pilots if needed
                Y_padded = [Y, zeros(size(Y, 1), obj.numRxAntennas - size(Y, 2))];
            else
                Y_padded = Y(:, 1:obj.numRxAntennas);
            end
            
            % LS estimation
            if rank(X_padded) == size(X_padded, 2)
                H = (Y_padded' * X_padded) * pinv(X_padded' * X_padded);
            else
                % Use pseudo-inverse for rank deficient matrices
                H = Y_padded' * pinv(X_padded');
            end
            
            % Ensure proper dimensions
            if size(H, 1) ~= obj.numRxAntennas || size(H, 2) ~= obj.numTxAntennas
                H = zeros(obj.numRxAntennas, obj.numTxAntennas);
                for i = 1:min(obj.numRxAntennas, size(Y_padded, 2))
                    for j = 1:min(obj.numTxAntennas, size(X_padded, 2))
                        if X_padded(1, j) ~= 0
                            H(i, j) = Y_padded(1, i) / X_padded(1, j);
                        else
                            H(i, j) = 1; % Default channel gain
                        end
                    end
                end
            end
        end
        
        function H = mmseEstimation(obj, X, Y)
            % MMSE channel estimation with prior knowledge
            % Assumes Rayleigh fading channel with known statistics
            
            % Start with LS estimate
            H_ls = obj.leastSquares(X, Y);
            
            % Apply MMSE refinement (simplified)
            % In practice, this would use channel correlation matrix
            noiseVariance = 0.1;
            channelVariance = 1.0;
            
            % MMSE filter
            alpha = channelVariance / (channelVariance + noiseVariance);
            H = alpha * H_ls;
        end
        
        function H = mlEstimation(obj, X, Y)
            % Maximum Likelihood estimation
            % For simplicity, use LS estimate as ML requires complex optimization
            H = obj.leastSquares(X, Y);
            
            % In practice, ML would maximize the likelihood function
            % L(H) = p(Y|X,H) assuming Gaussian noise
        end
        
        function H = adaptiveEstimation(obj, X, Y)
            % Adaptive channel estimation (e.g., LMS, RLS)
            % Simplified implementation using exponential forgetting
            
            H_current = obj.leastSquares(X, Y);
            
            % Simulated previous estimate (in practice, would be stored)
            persistent H_prev;
            if isempty(H_prev)
                H_prev = zeros(obj.numRxAntennas, obj.numTxAntennas);
            end
            
            % Adaptive filtering with forgetting factor
            forgettingFactor = 0.95;
            H = forgettingFactor * H_prev + (1 - forgettingFactor) * H_current;
            
            H_prev = H;
        end
        
        function H_filtered = temporalFiltering(obj, H)
            % Temporal filtering for time-varying channels
            % Simple first-order IIR filter
            
            persistent H_history;
            if isempty(H_history)
                H_history = H;
            end
            
            filterCoeff = 0.8; % Smoothing factor
            H_filtered = filterCoeff * H_history + (1 - filterCoeff) * H;
            
            H_history = H_filtered;
        end
        
        function mse = calculateMSE(obj, trueChannel, estimatedChannel)
            % Calculate Mean Square Error
            error = trueChannel - estimatedChannel;
            mse = mean(abs(error(:)).^2);
        end
        
        function condNum = calculateConditionNumber(obj, channelMatrix)
            % Calculate condition number of channel matrix
            condNum = cond(channelMatrix);
        end
        
        function isValid = validateEstimation(obj, estimatedChannel, tolerance)
            % Validation function for testbench integration
            if nargin < 3
                tolerance = 1e-3;
            end
            
            % Check for NaN or Inf values
            if any(isnan(estimatedChannel(:))) || any(isinf(estimatedChannel(:)))
                isValid = false;
                return;
            end
            
            % Check reasonable magnitude
            maxMagnitude = max(abs(estimatedChannel(:)));
            minMagnitude = min(abs(estimatedChannel(:)));
            
            if maxMagnitude > 100 || minMagnitude < tolerance
                isValid = false;
                return;
            end
            
            isValid = true;
        end
        
    end
end

%% Test Harness Functions

function runMIMOEncoderTest()
    % Test function for MIMO encoder
    fprintf('Running MIMO Encoder Test...\n');
    
    % Create encoder
    encoder = MIMOEncoder(4, 2, 16, 8);
    
    % Test data
    testData = [170, 85]; % 0xAA, 0x55
    
    % Test different configurations
    configurations = [
        0, 0; % SISO, BPSK
        1, 1; % SIMO, QPSK  
        2, 2; % MISO, 16-QAM
        3, 3; % MIMO, 64-QAM
    ];
    
    for i = 1:size(configurations, 1)
        mimoMode = configurations(i, 1);
        modType = configurations(i, 2);
        
        symbols = encoder.encode(testData, mimoMode, modType);
        
        fprintf('Config %d: MIMO=%d, Mod=%d, Symbols: ', i, mimoMode, modType);
        fprintf('%.4f+%.4fj ', real(symbols), imag(symbols));
        fprintf('\n');
    end
    
    fprintf('MIMO Encoder Test Completed.\n\n');
end

function runMIMODecoderTest()
    % Test function for MIMO decoder
    fprintf('Running MIMO Decoder Test...\n');
    
    % Create decoder
    decoder = MIMODecoder(4, 2);
    
    % Simulate received symbols
    rxSymbols = [0.8+0.1j; -0.7+0.2j; 0.9-0.1j; -0.8-0.1j];
    
    % Test channel matrix
    channelMatrix = [0.9+0.1j, 0.1+0.05j; 
                     0.05+0.1j, 0.8+0.2j;
                     0.1-0.1j, 0.9-0.05j;
                     0.05-0.02j, 0.1+0.8j];
    
    % Test different detection algorithms
    algorithms = [0, 1, 2, 3]; % ZF, MMSE, ML, SIC
    algorithmNames = {'ZF', 'MMSE', 'ML', 'SIC'};
    
    for i = 1:length(algorithms)
        decodedData = decoder.decode(rxSymbols, channelMatrix, 3, 1, algorithms(i));
        
        fprintf('Algorithm %s: Decoded data = [%d, %d]\n', ...
                algorithmNames{i}, decodedData(1), decodedData(2));
    end
    
    fprintf('MIMO Decoder Test Completed.\n\n');
end

function runChannelEstimatorTest()
    % Test function for channel estimator
    fprintf('Running Channel Estimator Test...\n');
    
    % Create estimator
    estimator = MIMOChannelEstimator(4, 4);
    
    % Generate test pilots
    txPilots = [1, 0, 1, 0; 0, 1, 0, 1; 1, 1, 0, 0; 0, 0, 1, 1]';
    
    % True channel (for simulation)
    trueChannel = [0.8+0.1j, 0.1+0.05j, 0.05-0.02j, 0.02+0.01j;
                   0.05+0.1j, 0.9+0.1j, 0.1+0.05j, 0.05-0.01j;
                   0.02-0.05j, 0.05+0.02j, 0.85+0.15j, 0.1+0.1j;
                   0.01+0.02j, 0.02-0.01j, 0.05+0.05j, 0.9+0.05j];
    
    % Generate received pilots
    noise = 0.01 * (randn(size(trueChannel)) + 1j*randn(size(trueChannel)));
    rxPilots = (trueChannel * txPilots + noise)';
    
    % Test different estimation algorithms
    algorithms = [0, 1, 2, 3];
    algorithmNames = {'LS', 'MMSE', 'ML', 'Adaptive'};
    
    for i = 1:length(algorithms)
        estimatedChannel = estimator.estimate(txPilots', rxPilots, ...
                                            algorithms(i), 0, false);
        
        mse = estimator.calculateMSE(trueChannel, estimatedChannel);
        condNum = estimator.calculateConditionNumber(estimatedChannel);
        
        fprintf('Algorithm %s: MSE = %.6f, Condition Number = %.2f\n', ...
                algorithmNames{i}, mse, condNum);
    end
    
    fprintf('Channel Estimator Test Completed.\n\n');
end

% Run all tests
if ~isdeployed
    runMIMOEncoderTest();
    runMIMODecoderTest();
    runChannelEstimatorTest();
    fprintf('All MATLAB reference model tests completed.\n');
end